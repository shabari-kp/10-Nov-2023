export const price :number = 4;
