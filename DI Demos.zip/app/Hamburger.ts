import { Injectable } from "@angular/core";

@Injectable()
export class Hamburger
{
    type:string;
    constructor()
    {
        console.log("constructor of Hamburger is created");
        this.type="Hamburger";
    }
}