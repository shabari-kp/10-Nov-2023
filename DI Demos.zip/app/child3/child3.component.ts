import { Component } from '@angular/core';
import { GenerateRandomNo } from '../GenerateRandomNo';

@Component({
  selector: 'app-child3',
  templateUrl: './child3.component.html',
  styleUrls: ['./child3.component.css'],
  providers:[GenerateRandomNo]
})
export class Child3Component {

  x:number;
  constructor(r:GenerateRandomNo) {
 this.x=r.value;
  }
}
