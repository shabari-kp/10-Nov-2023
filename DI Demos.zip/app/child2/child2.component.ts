import { Component } from '@angular/core';
import { GenerateRandomNo } from '../GenerateRandomNo';

@Component({
  selector: 'app-child2',
  templateUrl: './child2.component.html',
  styleUrls: ['./child2.component.css'],
  providers:[GenerateRandomNo]
})
export class Child2Component {
  x:number;
  constructor(r:GenerateRandomNo) {
 this.x=r.value;
  }
}
