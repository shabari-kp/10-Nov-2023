
import { Injectable } from "@angular/core";
import { Hamburger } from "./Hamburger";
import { DoubleHamburger } from "./DoubleHamburger";

@Injectable() //service class
export class CheeseHamburger extends DoubleHamburger
{
    type:string;
    constructor()
    {
         super(); // base class constructor() ie DoubleHamburger's constructor
        console.log("constructor of CheeseHamburger is created");
        this.type="CheeseHamburger";
    }
}