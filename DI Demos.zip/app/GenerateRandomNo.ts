import { Injectable } from "@angular/core";

@Injectable()
export class GenerateRandomNo
{
    value:number;
    constructor()

{
   console.log("constructor of service class is called");
   this.value=Math.random();

}


}