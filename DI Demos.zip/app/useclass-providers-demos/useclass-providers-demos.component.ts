import { Component } from '@angular/core';
import { Hamburger } from '../Hamburger';
import { DoubleHamburger } from '../DoubleHamburger';
import { CheeseHamburger } from '../CheeseHamburger';
@Component({
  selector: 'app-useclass-providers-demos',
  templateUrl: './useclass-providers-demos.component.html',
  styleUrls: ['./useclass-providers-demos.component.css'],
 // providers:[Hamburger,DoubleHamburger,CheeseHamburger]
 //providers:[{provide:Hamburger,useClass:Hamburger}]
 //providers:[Hamburger]

// runtime polymorphism
// providers:[{provide:Hamburger,useClass:DoubleHamburger}]
providers:[{provide:Hamburger,useClass:CheeseHamburger}]
})
export class UseclassProvidersDemosComponent {

  result:string;
  constructor(private h:Hamburger)
  //constructor(private h:DoubleCheeseHamburger)
  //constructor(private h:CheeseHamburger)//di

  {
    this.result=this.h.type;
  }
}
