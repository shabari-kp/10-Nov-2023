import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UseclassProvidersDemosComponent } from './useclass-providers-demos.component';

describe('UseclassProvidersDemosComponent', () => {
  let component: UseclassProvidersDemosComponent;
  let fixture: ComponentFixture<UseclassProvidersDemosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UseclassProvidersDemosComponent]
    });
    fixture = TestBed.createComponent(UseclassProvidersDemosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
