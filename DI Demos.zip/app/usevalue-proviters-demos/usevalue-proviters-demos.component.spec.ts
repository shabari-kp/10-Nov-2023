import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsevalueProvitersDemosComponent } from './usevalue-proviters-demos.component';

describe('UsevalueProvitersDemosComponent', () => {
  let component: UsevalueProvitersDemosComponent;
  let fixture: ComponentFixture<UsevalueProvitersDemosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UsevalueProvitersDemosComponent]
    });
    fixture = TestBed.createComponent(UsevalueProvitersDemosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
