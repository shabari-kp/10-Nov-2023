import { Component, Inject } from '@angular/core';

const API_url:string="";

@Component({
  selector: 'app-usevalue-proviters-demos',
  templateUrl: './usevalue-proviters-demos.component.html',
  styleUrls: ['./usevalue-proviters-demos.component.css'],
  providers:[{provide:API_url,useValue:'some value'}]
})
export class UsevalueProvitersDemosComponent {

  constructor(@Inject(API_url) str:string )
  {
  console.log(str);
  }

}
