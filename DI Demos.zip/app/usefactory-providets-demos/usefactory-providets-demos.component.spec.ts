import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsefactoryProvidetsDemosComponent } from './usefactory-providets-demos.component';

describe('UsefactoryProvidetsDemosComponent', () => {
  let component: UsefactoryProvidetsDemosComponent;
  let fixture: ComponentFixture<UsefactoryProvidetsDemosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UsefactoryProvidetsDemosComponent]
    });
    fixture = TestBed.createComponent(UsefactoryProvidetsDemosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
