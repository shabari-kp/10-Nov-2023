import { Component } from '@angular/core';
import { price } from 'src/environments/environment.development';
import { Hamburger } from '../Hamburger';
import { DoubleHamburger } from '../DoubleHamburger';
import { CheeseHamburger } from '../CheeseHamburger';

function checkPrice()
{
  if (price < 10 ) 
  {
    return new Hamburger();
  }
  else if (price > 10 && price < 15)
  {
    return new DoubleHamburger();
  }
  else if (price > 15) {
    return new CheeseHamburger();
  }
}


@Component({
  selector: 'app-usefactory-providets-demos',
  templateUrl: './usefactory-providets-demos.component.html',
  styleUrls: ['./usefactory-providets-demos.component.css'],
  providers:[{provide:Hamburger,useFactory:checkPrice}]
})
export class UsefactoryProvidetsDemosComponent {
  r:string;
constructor(private h:Hamburger) {
  this.r=h.type;
}
}
