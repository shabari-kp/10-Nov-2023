import { Component } from '@angular/core';

@Component({
  selector: 'app-inj-tokens-demos',
  templateUrl: './inj-tokens-demos.component.html',
  styleUrls: ['./inj-tokens-demos.component.css']
})
export class InjTokensDemosComponent {

}
