import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InjTokensDemosComponent } from './inj-tokens-demos.component';

describe('InjTokensDemosComponent', () => {
  let component: InjTokensDemosComponent;
  let fixture: ComponentFixture<InjTokensDemosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [InjTokensDemosComponent]
    });
    fixture = TestBed.createComponent(InjTokensDemosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
