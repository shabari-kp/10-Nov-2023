
import { Injectable } from "@angular/core";
import { Hamburger } from "./Hamburger";

@Injectable()
export class DoubleHamburger extends Hamburger
{
    type:string;
    constructor()
    {
         super(); // base class constructor() ie hamburger's constructor
        console.log("constructor of DoubleHamburger is created");
        this.type="DoubleHamburger";
    }
}