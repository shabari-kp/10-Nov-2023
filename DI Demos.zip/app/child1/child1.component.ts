import { Component } from '@angular/core';
import { GenerateRandomNo } from '../GenerateRandomNo';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css']
})
export class Child1Component 
{
  x:number;
  constructor(r:GenerateRandomNo) {
 this.x=r.value;
 
}
}
